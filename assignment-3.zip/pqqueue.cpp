// NONMEMBER FUNCTION IMPLEMENTATIONS

#include "pqqueue.h"



